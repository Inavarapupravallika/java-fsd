package FileOperations;
	import java.io.*;

	public class FileCRUDExamples {
	    public static void main(String[] args) {
	        // Specify the file path
	        String filePath = "example.txt";

	        // Create a file
	        createFile(filePath);

	        // Read from the file
	        String fileContent = readFile(filePath);
	        System.out.println("File Content:\n" + fileContent);

	        // Update the file
	        String updatedContent = "This is the updated content.";
	        updateFile(filePath, updatedContent);

	        // Read the updated content
	        String updatedFileContent = readFile(filePath);
	        System.out.println("Updated File Content:\n" + updatedFileContent);

	        // Delete the file
	        deleteFile(filePath);
	    }

	    // Create a file
	    public static void createFile(String filePath) {
	        try {
	            File file = new File(filePath);
	            if (file.createNewFile()) {
	                System.out.println("File created: " + filePath);
	            } else {
	                System.out.println("File already exists.");
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    // Read from a file
	    public static String readFile(String filePath) {
	        StringBuilder content = new StringBuilder();
	        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                content.append(line).append("\n");
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        return content.toString();
	    }

	    // Update a file
	    public static void updateFile(String filePath, String content) {
	        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
	            writer.write(content);
	            System.out.println("File updated.");
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    // Delete a file
	    public static void deleteFile(String filePath) {
	        File file = new File(filePath);
	        if (file.delete()) {
	            System.out.println("File deleted: " + filePath);
	        } else {
	            System.out.println("Failed to delete the file.");
	        }
	    }
	}
