package innerclass;

	abstract class AnonymousInnerClass {
		   public abstract void display();
		}



	public class innerclass {
		private String msg="Welcome to Java"; 
		 
		 class Inner{  
		  void hello(){System.out.println(msg+", Let us start learning Inner Classes");}  
		 }  

		 private String msg1="Inner Classes";

		 void display(){  
			 class Inner{  
				 void msg1(){
					 System.out.println(msg1);
				 }  
		  }  
		  
		  Inner l=new Inner();  
		  l.msg1();  
		 }  



		
		public static void main(String[] args) {
			innerclass obj=new innerclass();
			innerclass.Inner in=obj.new Inner();  
			in.hello(); 
			innerclass ob=new innerclass();  
			ob.display();  

			
			AnonymousInnerClass i = new AnonymousInnerClass() 
			
					{
		         public void display()
		         {
		            System.out.println("Anonymous Inner Class");
		         }
					};
			
		      i.display();
		}
}
