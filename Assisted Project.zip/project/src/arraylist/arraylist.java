package arraylist;

public class arraylist {

	public static void main(String[] args) {

		int a[]= {25,35,45,55,65,70};
		for(int i=0;i<5;i++) {
		System.out.println("Elements of array a: "+a[i]);
		}


		int[][] b = {
		            {1,2,3,4,6}, 
		            {7,8,8,9} };
		      
		      System.out.println("\nLength of row 1: " + b[0].length);
		      System.out.println("\nLength of row 2: " + b[1].length);
		      }
		}


	
