package accessModifiers;

public class accessSpecifiers {
    public String publicField = "This is a public field";

    public accessSpecifiers() {
        System.out.println("This is a public constructor");
    }

    public void publicMethod() {
        System.out.println("This is a public method");
    }
    
    public static void main(String[] args) {
        accessSpecifiers example = new accessSpecifiers();
        System.out.println("Public field: " + example.publicField);
        example.publicMethod();

        OtherClass other = new OtherClass();
        other.demoAccessSpecifiers();
    }
}

class OtherClass {
    String packagePrivateField = "This is a package-private (default) field";
    OtherClass() {
        System.out.println("This is a package-private (default) constructor");
    }

    private void privateMethod() {
        System.out.println("This is a private method");
    }

    protected void protectedMethod() {
        System.out.println("This is a protected method");
    }

    void packagePrivateMethod() {
        System.out.println("This is a package-private (default) method");
    }

    void demoAccessSpecifiers() {
        System.out.println("Package-private field: " + packagePrivateField);
        System.out.println("Calling package-private method...");
        packagePrivateMethod();

        System.out.println("Calling private method...");
        privateMethod();
        System.out.println("Calling protected method...");
        protectedMethod();
    }
}






