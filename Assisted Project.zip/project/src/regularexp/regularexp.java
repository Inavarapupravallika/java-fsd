package regularexp;
import java.util.regex.*;

	public class regularexp {

		public static void main(String[] args) {

		String pattern = "[A-Z][a-z]+";
		String check = "Software Developer";
		Pattern p = Pattern.compile(pattern);
		Matcher c = p.matcher(check);
		
		while (c.find())
	      	System.out.println( check.substring( c.start(), c.end() ) );
		}
	}


